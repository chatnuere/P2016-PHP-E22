# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# H�te: localhost (MySQL 5.5.33)
# Base de donn�es: scrapp
# Temps de g�n�ration: 2014-02-14 14:01:43 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Affichage de la table photo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `photo`;

CREATE TABLE `photo` (
  `id_photo` int(11) NOT NULL AUTO_INCREMENT,
  `chemin` varchar(300) NOT NULL,
  `longitude` float NOT NULL,
  `latitude` float NOT NULL,
  `arrondissement` int(11) DEFAULT NULL,
  `pollution` int(11) DEFAULT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id_photo`),
  KEY `id_user_idx` (`id_user`),
  CONSTRAINT `id_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `photo` WRITE;
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;

INSERT INTO `photo` (`id_photo`, `chemin`, `longitude`, `latitude`, `arrondissement`, `pollution`, `id_user`)
VALUES
	(1,'http://www.hd-wallpaper.images-fonds.com/modules/mg3/albums/Art_Digital_Wallpaper_HD/3D_Landscape/3D_Landscape_wallpaper_HD_0006.jpg',2.352,48.855,3,5,1),
	(2,'http://www.hd-wallpaper.images-fonds.com/modules/mg3/albums/Art_Digital_Wallpaper_HD/3D_Landscape/3D_Landscape_wallpaper_HD_0006.jpg',2.253,48.755,17,4,3),
	(3,'http://gph.is/Nc6YQF',2.233,48.643,1,3,2),
	(4,'http://gph.is/XK9yQO',2.333,48.822,2,2,1),
	(5,'http://gph.is/17xENU',2.222,48.888,3,1,2),
	(6,'http://gph.is/XL4dZt',2.333,48.777,4,5,3),
	(7,'http://gph.is/XIp6Vb',2.321,48.765,5,4,1),
	(8,'http://gph.is/1jjxRxn',2.123,48.567,6,3,2),
	(9,'http://gph.is/XK4bkr',2.252,48.855,7,2,3),
	(10,'http://gph.is/YZSgel',2.152,48.876,8,1,1),
	(11,'http://gph.is/1abeVsD',2.234,48.834,9,5,2),
	(12,'http://gph.is/XLJDIq',2.278,48.734,10,4,3),
	(13,'http://gph.is/1blp2vS',2.369,48.817,11,3,1),
	(14,'http://gph.is/17jmfSU',2.364,48.835,12,2,2),
	(15,'http://gph.is/VxjsTw',2.348,48.799,13,1,3),
	(16,'http://gph.is/17h3j8X',2.265,48.734,14,5,1),
	(17,'http://gph.is/VwBJAi',2.333,48.888,15,4,2),
	(18,'http://gph.is/XNeog6',2.354,48.834,16,3,3),
	(19,'http://gph.is/XKwgrQ',2.362,48.812,17,2,1),
	(20,'http://gph.is/VwBftX',2.326,48.888,18,1,3),
	(21,'http://gph.is/13n5CVg',2.356,48.856,19,5,2),
	(22,'http://gph.is/VwuQPl',2.341,48.822,20,4,1),
	(23,'http://www.mon-diplome.fr/Diplome/700-245765-Dipl%C3%B4me%20du%20agrou-agrou%20niveau%2029.jpg',2.357,48.855,3,2,2);

/*!40000 ALTER TABLE `photo` ENABLE KEYS */;
UNLOCK TABLES;


# Affichage de la table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(45) NOT NULL,
  `mdp` varchar(45) NOT NULL,
  `mail` varchar(255) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;

INSERT INTO `user` (`id_user`, `pseudo`, `mdp`, `mail`)
VALUES
	(1,'Justine','mdp01','justine@hetic.net'),
	(2,'Sam','mdp02','sam@hetic.net'),
	(3,'Anaïs','mdp03','anais@hetic.net');

/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
